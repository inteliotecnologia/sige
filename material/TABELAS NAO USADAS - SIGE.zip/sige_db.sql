-- phpMyAdmin SQL Dump
-- version 2.9.1.1-Debian-4
-- http://www.phpmyadmin.net
-- 
-- Servidor: 
-- Tempo de Geração: Set 30, 2011 as 05:57 PM
-- Versão do Servidor: 5.0.32
-- Versão do PHP: 5.2.0-8+etch16
-- 
-- Banco de Dados: `sige_db`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_acl`
-- 

CREATE TABLE `agua_acl` (
  `id_acl` int(11) NOT NULL auto_increment,
  `id_empresa` int(11) default NULL,
  `data_acl` date default NULL,
  `responsavel_tecnico` varchar(255) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id_acl`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

-- 
-- Extraindo dados da tabela `agua_acl`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_acl_cond`
-- 

CREATE TABLE `agua_acl_cond` (
  `id` int(11) NOT NULL auto_increment,
  `id_acl` int(11) default NULL,
  `id_carac` int(11) default NULL,
  `antes` varchar(127) collate latin1_general_ci default NULL,
  `apos` varchar(127) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=191 ;

-- 
-- Extraindo dados da tabela `agua_acl_cond`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_acl_prod`
-- 

CREATE TABLE `agua_acl_prod` (
  `id` int(11) NOT NULL auto_increment,
  `id_acl` int(11) default NULL,
  `id_prod` int(11) default NULL,
  `produto` varchar(255) collate latin1_general_ci default NULL,
  `qtde` float(7,2) default NULL,
  `vol_solucao` float(7,2) default NULL,
  `ri` int(11) default NULL,
  `tr` int(11) default NULL,
  `rf` int(11) default NULL,
  `cor` int(11) default NULL,
  `ph` int(11) default NULL,
  `temp` float(7,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=191 ;

-- 
-- Extraindo dados da tabela `agua_acl_prod`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_cp`
-- 

CREATE TABLE `agua_cp` (
  `id_cp` int(11) NOT NULL auto_increment,
  `data_cp` date default NULL,
  `id_empresa` int(11) default NULL,
  `qtde_equipamentos` int(11) default NULL,
  `obs` text collate latin1_general_ci,
  `conclusao_final` text collate latin1_general_ci,
  `ver_responsavel` varchar(255) collate latin1_general_ci default NULL,
  `ver_cargo` varchar(255) collate latin1_general_ci default NULL,
  `sis_responsavel` varchar(255) collate latin1_general_ci default NULL,
  `sis_cargo` varchar(255) collate latin1_general_ci default NULL,
  `ultima_atualizacao` timestamp NULL default NULL,
  PRIMARY KEY  (`id_cp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=8 ;

-- 
-- Extraindo dados da tabela `agua_cp`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_cp_analise`
-- 

CREATE TABLE `agua_cp_analise` (
  `id` int(11) NOT NULL auto_increment,
  `id_cp` int(11) default NULL,
  `id_carac` int(11) default NULL,
  `parametro` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=189 ;

-- 
-- Extraindo dados da tabela `agua_cp_analise`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_cp_equipamentos`
-- 

CREATE TABLE `agua_cp_equipamentos` (
  `id` int(11) NOT NULL auto_increment,
  `id_cp` int(11) default NULL,
  `id_eq` int(11) default NULL,
  `condicao` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=231 ;

-- 
-- Extraindo dados da tabela `agua_cp_equipamentos`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_cp_filtros`
-- 

CREATE TABLE `agua_cp_filtros` (
  `id` int(11) NOT NULL auto_increment,
  `id_cp` int(11) default NULL,
  `filtro` int(11) default NULL,
  `troca` tinyint(3) default NULL,
  `data_troca` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=211 ;

-- 
-- Extraindo dados da tabela `agua_cp_filtros`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct`
-- 

CREATE TABLE `agua_ct` (
  `id_ct` int(11) NOT NULL auto_increment,
  `data_ct` date default NULL,
  `id_empresa` int(11) default NULL,
  `qe_qtde` int(11) default NULL,
  `qe_obs` text collate latin1_general_ci,
  `ba_qtde` int(11) default NULL,
  `ba_obs` text collate latin1_general_ci,
  `fa_qtde` int(11) default NULL,
  `fa_obs` text collate latin1_general_ci,
  `fa_conclusao_final` text collate latin1_general_ci,
  `ab_qtde` int(11) default NULL,
  `ab_obs` text collate latin1_general_ci,
  `ab_conclusao_final` text collate latin1_general_ci,
  `fc_qtde` int(11) default NULL,
  `fc_obs` text collate latin1_general_ci,
  `fc_conclusao_final` text collate latin1_general_ci,
  `or_qtde` int(11) default NULL,
  `or_obs` text collate latin1_general_ci,
  `or_conclusao_final` text collate latin1_general_ci,
  `br_qtde` int(11) default NULL,
  `br_obs` text collate latin1_general_ci,
  `br_conclusao_final` text collate latin1_general_ci,
  `ts_qtde` int(11) default NULL,
  `ts_obs` text collate latin1_general_ci,
  `fil_qtde` int(11) default NULL,
  `ver_responsavel` varchar(255) collate latin1_general_ci default NULL,
  `ver_cargo` varchar(255) collate latin1_general_ci default NULL,
  `sis_responsavel` varchar(255) collate latin1_general_ci default NULL,
  `sis_cargo` varchar(255) collate latin1_general_ci default NULL,
  `ultima_atualizacao` timestamp NULL default NULL,
  PRIMARY KEY  (`id_ct`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=14 ;

-- 
-- Extraindo dados da tabela `agua_ct`
-- 

INSERT INTO `agua_ct` (`id_ct`, `data_ct`, `id_empresa`, `qe_qtde`, `qe_obs`, `ba_qtde`, `ba_obs`, `fa_qtde`, `fa_obs`, `fa_conclusao_final`, `ab_qtde`, `ab_obs`, `ab_conclusao_final`, `fc_qtde`, `fc_obs`, `fc_conclusao_final`, `or_qtde`, `or_obs`, `or_conclusao_final`, `br_qtde`, `br_obs`, `br_conclusao_final`, `ts_qtde`, `ts_obs`, `fil_qtde`, `ver_responsavel`, `ver_cargo`, `sis_responsavel`, `sis_cargo`, `ultima_atualizacao`) VALUES 
(13, '2008-04-07', 2, 0, '', 0, '', 0, '', '', 0, '', '', 0, '', '', 0, '', '', 0, '', '', 0, '', 0, '', '', '', '', NULL);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct1_ba_av`
-- 

CREATE TABLE `agua_ct1_ba_av` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_comp_ba` int(11) default NULL,
  `problema_ba` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=41 ;

-- 
-- Extraindo dados da tabela `agua_ct1_ba_av`
-- 

INSERT INTO `agua_ct1_ba_av` (`id`, `id_ct`, `id_comp_ba`, `problema_ba`) VALUES 
(39, 13, 1, 0),
(40, 13, 2, 0);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct1_ba_eq`
-- 

CREATE TABLE `agua_ct1_ba_eq` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_eq_ba` int(11) default NULL,
  `b1_ba` float(7,2) default NULL,
  `b2_ba` float(7,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=41 ;

-- 
-- Extraindo dados da tabela `agua_ct1_ba_eq`
-- 

INSERT INTO `agua_ct1_ba_eq` (`id`, `id_ct`, `id_eq_ba`, `b1_ba`, `b2_ba`) VALUES 
(39, 13, 1, 0.00, 0.00),
(40, 13, 2, 0.00, 0.00);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct1_equipamentos`
-- 

CREATE TABLE `agua_ct1_equipamentos` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_eq` int(11) default NULL,
  `condicao` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=321 ;

-- 
-- Extraindo dados da tabela `agua_ct1_equipamentos`
-- 

INSERT INTO `agua_ct1_equipamentos` (`id`, `id_ct`, `id_eq`, `condicao`) VALUES 
(311, 13, 1, 1),
(312, 13, 2, 1),
(313, 13, 3, 1),
(314, 13, 4, 1),
(315, 13, 5, 1),
(316, 13, 6, 1),
(317, 13, 7, 1),
(318, 13, 8, 1),
(319, 13, 9, 1),
(320, 13, 10, 1);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct1_fa_ag`
-- 

CREATE TABLE `agua_ct1_fa_ag` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_ag_fa` int(11) default NULL,
  `c1_ag_entrada_fa` float(7,2) default NULL,
  `c1_ag_saida_fa` float(7,2) default NULL,
  `c2_ag_entrada_fa` float(7,2) default NULL,
  `c2_ag_saida_fa` float(7,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=101 ;

-- 
-- Extraindo dados da tabela `agua_ct1_fa_ag`
-- 

INSERT INTO `agua_ct1_fa_ag` (`id`, `id_ct`, `id_ag_fa`, `c1_ag_entrada_fa`, `c1_ag_saida_fa`, `c2_ag_entrada_fa`, `c2_ag_saida_fa`) VALUES 
(96, 13, 1, 0.00, 0.00, 0.00, 0.00),
(97, 13, 2, 0.00, 0.00, 0.00, 0.00),
(98, 13, 3, 0.00, 0.00, 0.00, 0.00),
(99, 13, 4, 0.00, 0.00, 0.00, 0.00),
(100, 13, 5, 0.00, 0.00, 0.00, 0.00);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct1_fa_av`
-- 

CREATE TABLE `agua_ct1_fa_av` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_comp_fa` int(11) default NULL,
  `problema_fa` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=61 ;

-- 
-- Extraindo dados da tabela `agua_ct1_fa_av`
-- 

INSERT INTO `agua_ct1_fa_av` (`id`, `id_ct`, `id_comp_fa`, `problema_fa`) VALUES 
(58, 13, 1, 0),
(59, 13, 2, 0),
(60, 13, 3, 0);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct1_fa_eq`
-- 

CREATE TABLE `agua_ct1_fa_eq` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_eq_fa` int(11) default NULL,
  `c1_eq_entrada_fa` float(7,2) default NULL,
  `c1_eq_saida_fa` float(7,2) default NULL,
  `c2_eq_entrada_fa` float(7,2) default NULL,
  `c2_eq_saida_fa` float(7,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=21 ;

-- 
-- Extraindo dados da tabela `agua_ct1_fa_eq`
-- 

INSERT INTO `agua_ct1_fa_eq` (`id`, `id_ct`, `id_eq_fa`, `c1_eq_entrada_fa`, `c1_eq_saida_fa`, `c2_eq_entrada_fa`, `c2_eq_saida_fa`) VALUES 
(20, 13, 1, 0.00, 0.00, 0.00, 0.00);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct1_qe_av`
-- 

CREATE TABLE `agua_ct1_qe_av` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_comp_qe` int(11) default NULL,
  `problema_qe` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=61 ;

-- 
-- Extraindo dados da tabela `agua_ct1_qe_av`
-- 

INSERT INTO `agua_ct1_qe_av` (`id`, `id_ct`, `id_comp_qe`, `problema_qe`) VALUES 
(58, 13, 1, 0),
(59, 13, 2, 0),
(60, 13, 3, 0);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct2_ab_ag`
-- 

CREATE TABLE `agua_ct2_ab_ag` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_ag_ab` int(11) default NULL,
  `c1_ag_entrada_ab` float(7,2) default NULL,
  `c1_ag_saida_ab` float(7,2) default NULL,
  `c2_ag_entrada_ab` float(7,2) default NULL,
  `c2_ag_saida_ab` float(7,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=99 ;

-- 
-- Extraindo dados da tabela `agua_ct2_ab_ag`
-- 

INSERT INTO `agua_ct2_ab_ag` (`id`, `id_ct`, `id_ag_ab`, `c1_ag_entrada_ab`, `c1_ag_saida_ab`, `c2_ag_entrada_ab`, `c2_ag_saida_ab`) VALUES 
(96, 13, 1, 0.00, 0.00, 0.00, 0.00),
(97, 13, 2, 0.00, 0.00, 0.00, 0.00),
(98, 13, 3, 0.00, 0.00, 0.00, 0.00);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct2_ab_av`
-- 

CREATE TABLE `agua_ct2_ab_av` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_comp_ab` int(11) default NULL,
  `problema_ab` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=85 ;

-- 
-- Extraindo dados da tabela `agua_ct2_ab_av`
-- 

INSERT INTO `agua_ct2_ab_av` (`id`, `id_ct`, `id_comp_ab`, `problema_ab`) VALUES 
(81, 13, 1, 0),
(82, 13, 2, 0),
(83, 13, 3, 0),
(84, 13, 4, 0);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct2_ab_eq`
-- 

CREATE TABLE `agua_ct2_ab_eq` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_eq_ab` int(11) default NULL,
  `c1_eq_entrada_ab` float(7,2) default NULL,
  `c1_eq_saida_ab` float(7,2) default NULL,
  `c2_eq_entrada_ab` float(7,2) default NULL,
  `c2_eq_saida_ab` float(7,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=27 ;

-- 
-- Extraindo dados da tabela `agua_ct2_ab_eq`
-- 

INSERT INTO `agua_ct2_ab_eq` (`id`, `id_ct`, `id_eq_ab`, `c1_eq_entrada_ab`, `c1_eq_saida_ab`, `c2_eq_entrada_ab`, `c2_eq_saida_ab`) VALUES 
(26, 13, 1, 0.00, 0.00, 0.00, 0.00);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct2_fc_ag`
-- 

CREATE TABLE `agua_ct2_fc_ag` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_ag_fc` int(11) default NULL,
  `c1_ag_entrada_fc` float(7,2) default NULL,
  `c1_ag_saida_fc` float(7,2) default NULL,
  `c2_ag_entrada_fc` float(7,2) default NULL,
  `c2_ag_saida_fc` float(7,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=115 ;

-- 
-- Extraindo dados da tabela `agua_ct2_fc_ag`
-- 

INSERT INTO `agua_ct2_fc_ag` (`id`, `id_ct`, `id_ag_fc`, `c1_ag_entrada_fc`, `c1_ag_saida_fc`, `c2_ag_entrada_fc`, `c2_ag_saida_fc`) VALUES 
(111, 13, 1, 0.00, 0.00, 0.00, 0.00),
(112, 13, 2, 0.00, 0.00, 0.00, 0.00),
(113, 13, 3, 0.00, 0.00, 0.00, 0.00),
(114, 13, 4, 0.00, 0.00, 0.00, 0.00);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct2_fc_av`
-- 

CREATE TABLE `agua_ct2_fc_av` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_comp_fc` int(11) default NULL,
  `problema_fc` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=69 ;

-- 
-- Extraindo dados da tabela `agua_ct2_fc_av`
-- 

INSERT INTO `agua_ct2_fc_av` (`id`, `id_ct`, `id_comp_fc`, `problema_fc`) VALUES 
(66, 13, 1, 0),
(67, 13, 2, 0),
(68, 13, 3, 0);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct2_fc_eq`
-- 

CREATE TABLE `agua_ct2_fc_eq` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_eq_fc` int(11) default NULL,
  `c1_eq_entrada_fc` float(7,2) default NULL,
  `c1_eq_saida_fc` float(7,2) default NULL,
  `c2_eq_entrada_fc` float(7,2) default NULL,
  `c2_eq_saida_fc` float(7,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=27 ;

-- 
-- Extraindo dados da tabela `agua_ct2_fc_eq`
-- 

INSERT INTO `agua_ct2_fc_eq` (`id`, `id_ct`, `id_eq_fc`, `c1_eq_entrada_fc`, `c1_eq_saida_fc`, `c2_eq_entrada_fc`, `c2_eq_saida_fc`) VALUES 
(26, 13, 1, 0.00, 0.00, 0.00, 0.00);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct3_br_av`
-- 

CREATE TABLE `agua_ct3_br_av` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_comp_br` int(11) default NULL,
  `problema_br` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=37 ;

-- 
-- Extraindo dados da tabela `agua_ct3_br_av`
-- 

INSERT INTO `agua_ct3_br_av` (`id`, `id_ct`, `id_comp_br`, `problema_br`) VALUES 
(35, 13, 1, 0),
(36, 13, 2, 0);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct3_br_eq`
-- 

CREATE TABLE `agua_ct3_br_eq` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_eq_br` int(11) default NULL,
  `b1_br` float(7,2) default NULL,
  `b2_br` float(7,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=35 ;

-- 
-- Extraindo dados da tabela `agua_ct3_br_eq`
-- 

INSERT INTO `agua_ct3_br_eq` (`id`, `id_ct`, `id_eq_br`, `b1_br`, `b2_br`) VALUES 
(32, 13, 1, 0.00, 0.00),
(33, 13, 2, 0.00, 0.00),
(34, 13, 3, 0.00, 0.00);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct3_or_ag`
-- 

CREATE TABLE `agua_ct3_or_ag` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_ag_or` int(11) default NULL,
  `c1_ag_entrada_or` float(7,2) default NULL,
  `c1_ag_saida_or` float(7,2) default NULL,
  `c2_ag_entrada_or` float(7,2) default NULL,
  `c2_ag_saida_or` float(7,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=83 ;

-- 
-- Extraindo dados da tabela `agua_ct3_or_ag`
-- 

INSERT INTO `agua_ct3_or_ag` (`id`, `id_ct`, `id_ag_or`, `c1_ag_entrada_or`, `c1_ag_saida_or`, `c2_ag_entrada_or`, `c2_ag_saida_or`) VALUES 
(79, 13, 1, 0.00, 0.00, 0.00, 0.00),
(80, 13, 2, 0.00, 0.00, 0.00, 0.00),
(81, 13, 3, 0.00, 0.00, 0.00, 0.00),
(82, 13, 4, 0.00, 0.00, 0.00, 0.00);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct3_or_av`
-- 

CREATE TABLE `agua_ct3_or_av` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_comp_or` int(11) default NULL,
  `problema_or` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=45 ;

-- 
-- Extraindo dados da tabela `agua_ct3_or_av`
-- 

INSERT INTO `agua_ct3_or_av` (`id`, `id_ct`, `id_comp_or`, `problema_or`) VALUES 
(42, 13, 1, 0),
(43, 13, 2, 0),
(44, 13, 3, 0);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct3_or_eq`
-- 

CREATE TABLE `agua_ct3_or_eq` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_eq_or` int(11) default NULL,
  `c1_eq_entrada_or` float(7,2) default NULL,
  `c1_eq_saida_or` float(7,2) default NULL,
  `c2_eq_entrada_or` float(7,2) default NULL,
  `c2_eq_saida_or` float(7,2) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=75 ;

-- 
-- Extraindo dados da tabela `agua_ct3_or_eq`
-- 

INSERT INTO `agua_ct3_or_eq` (`id`, `id_ct`, `id_eq_or`, `c1_eq_entrada_or`, `c1_eq_saida_or`, `c2_eq_entrada_or`, `c2_eq_saida_or`) VALUES 
(67, 13, 1, 0.00, 0.00, 0.00, 0.00),
(68, 13, 2, 0.00, 0.00, 0.00, 0.00),
(69, 13, 3, 0.00, 0.00, 0.00, 0.00),
(70, 13, 4, 0.00, 0.00, 0.00, 0.00),
(71, 13, 5, 0.00, 0.00, 0.00, 0.00),
(72, 13, 6, 0.00, 0.00, 0.00, 0.00),
(73, 13, 7, 0.00, 0.00, 0.00, 0.00),
(74, 13, 8, 0.00, 0.00, 0.00, 0.00);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct3_ts_av`
-- 

CREATE TABLE `agua_ct3_ts_av` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `id_comp_ts` int(11) default NULL,
  `problema_ts` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=45 ;

-- 
-- Extraindo dados da tabela `agua_ct3_ts_av`
-- 

INSERT INTO `agua_ct3_ts_av` (`id`, `id_ct`, `id_comp_ts`, `problema_ts`) VALUES 
(42, 13, 1, 0),
(43, 13, 2, 0),
(44, 13, 3, 0);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ct4_filtros`
-- 

CREATE TABLE `agua_ct4_filtros` (
  `id` int(11) NOT NULL auto_increment,
  `id_ct` int(11) default NULL,
  `filtro` int(11) default NULL,
  `troca` tinyint(3) default NULL,
  `data_troca` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=151 ;

-- 
-- Extraindo dados da tabela `agua_ct4_filtros`
-- 

INSERT INTO `agua_ct4_filtros` (`id`, `id_ct`, `filtro`, `troca`, `data_troca`) VALUES 
(141, 13, 1, 0, '0000-00-00'),
(142, 13, 2, 0, '0000-00-00'),
(143, 13, 3, 0, '0000-00-00'),
(144, 13, 4, 0, '0000-00-00'),
(145, 13, 5, 0, '0000-00-00'),
(146, 13, 6, 0, '0000-00-00'),
(147, 13, 7, 0, '0000-00-00'),
(148, 13, 8, 0, '0000-00-00'),
(149, 13, 9, 0, '0000-00-00'),
(150, 13, 10, 0, '0000-00-00');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_mce`
-- 

CREATE TABLE `agua_mce` (
  `id_mce` int(11) NOT NULL auto_increment,
  `tipo` char(1) collate latin1_general_ci default '',
  `id_empresa` int(11) default NULL,
  `mes` int(11) default NULL,
  `ano` year(4) default NULL,
  `data_coleta` date default NULL,
  `n_laudo` varchar(255) collate latin1_general_ci default NULL,
  `resultado` varchar(255) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id_mce`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=9 ;

-- 
-- Extraindo dados da tabela `agua_mce`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_ml`
-- 

CREATE TABLE `agua_ml` (
  `id_ml` int(11) NOT NULL auto_increment,
  `id_empresa` int(11) default NULL,
  `mes` int(11) default NULL,
  `ano` year(4) default NULL,
  `data_limpeza` date default NULL,
  `data_ver` date default NULL,
  PRIMARY KEY  (`id_ml`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=10 ;

-- 
-- Extraindo dados da tabela `agua_ml`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_vt`
-- 

CREATE TABLE `agua_vt` (
  `id_vt` int(11) NOT NULL auto_increment,
  `id_empresa` int(11) default NULL,
  `n_visitas` int(11) default NULL,
  `data_inicial` date default NULL,
  `data_final` date default NULL,
  `n_oss` varchar(255) collate latin1_general_ci default NULL,
  `recomendacoes` text collate latin1_general_ci,
  `solicitacao_pecas` text collate latin1_general_ci,
  `valor_total` float(7,2) default NULL,
  `ver_responsavel` varchar(255) collate latin1_general_ci default NULL,
  `ver_cargo` varchar(255) collate latin1_general_ci default NULL,
  `sis_responsavel` varchar(255) collate latin1_general_ci default NULL,
  `sis_cargo` varchar(255) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id_vt`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

-- 
-- Extraindo dados da tabela `agua_vt`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_vt_equipamentos`
-- 

CREATE TABLE `agua_vt_equipamentos` (
  `id` int(11) NOT NULL auto_increment,
  `id_vt` int(11) default NULL,
  `id_eq` int(11) default NULL,
  `condicao` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=111 ;

-- 
-- Extraindo dados da tabela `agua_vt_equipamentos`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `agua_vt_filtros`
-- 

CREATE TABLE `agua_vt_filtros` (
  `id` int(11) NOT NULL auto_increment,
  `id_vt` int(11) default NULL,
  `id_filtro` int(11) default NULL,
  `filtro` int(11) default NULL,
  `data_troca` date default NULL,
  `qtde_total` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=46 ;

-- 
-- Extraindo dados da tabela `agua_vt_filtros`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `equipamentos`
-- 

CREATE TABLE `equipamentos` (
  `id_eq` int(11) NOT NULL auto_increment,
  `id_empresa` int(11) default NULL,
  `ident` int(11) default NULL,
  `modelo` int(11) default NULL,
  `n_serie` varchar(255) collate latin1_general_ci default NULL,
  `voltagem` int(11) default NULL,
  `classe` int(11) default NULL,
  `tipo` int(11) default NULL,
  `dimensoes` varchar(255) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id_eq`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

-- 
-- Extraindo dados da tabela `equipamentos`
-- 

INSERT INTO `equipamentos` (`id_eq`, `id_empresa`, `ident`, `modelo`, `n_serie`, `voltagem`, `classe`, `tipo`, `dimensoes`) VALUES 
(1, 2, 2, 1, '123xxx1', 110, 1, 1, 'qwerty'),
(2, 2, 1, 1, '123123-123123--3123', 0, 1, 1, 'aaaaaaaa'),
(3, 2, 1, 1, 'zxczxc09as8d0z', 110, 2, 2, 'qqqqqqqqq'),
(4, 2, 1, 1, '123123123123123', 0, 1, 1, 'ccccccccc');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `fluxo`
-- 

CREATE TABLE `fluxo` (
  `id_fluxo` int(11) NOT NULL auto_increment,
  `id_empresa` int(11) default NULL,
  `id_eq` char(1) collate latin1_general_ci default NULL,
  `dimensoes` varchar(255) collate latin1_general_ci default NULL,
  `pf_qtde` int(11) default NULL,
  `pf_ef` int(11) default NULL,
  `pf_marca` varchar(255) collate latin1_general_ci default NULL,
  `f_qtde` int(11) default NULL,
  `f_ef` int(11) default NULL,
  `f_marca` varchar(255) collate latin1_general_ci default NULL,
  `teste_vel_espec` int(11) default NULL,
  `teste_cont_espec` int(11) default NULL,
  `teste_fuga_vaz` int(11) default NULL,
  `teste_fuga_rep` int(11) default NULL,
  `avaliacao_final` varchar(255) collate latin1_general_ci default NULL,
  `especificacao` text collate latin1_general_ci,
  `obs` text collate latin1_general_ci,
  `iso_classe` varchar(255) collate latin1_general_ci default NULL,
  `inspecionado` varchar(255) collate latin1_general_ci default NULL,
  `data_inspecao` date default NULL,
  `responsavel_tecnico` varchar(255) collate latin1_general_ci default NULL,
  `ultima_atualizacao` date default NULL,
  PRIMARY KEY  (`id_fluxo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

-- 
-- Extraindo dados da tabela `fluxo`
-- 

INSERT INTO `fluxo` (`id_fluxo`, `id_empresa`, `id_eq`, `dimensoes`, `pf_qtde`, `pf_ef`, `pf_marca`, `f_qtde`, `f_ef`, `f_marca`, `teste_vel_espec`, `teste_cont_espec`, `teste_fuga_vaz`, `teste_fuga_rep`, `avaliacao_final`, `especificacao`, `obs`, `iso_classe`, `inspecionado`, `data_inspecao`, `responsavel_tecnico`, `ultima_atualizacao`) VALUES 
(4, 2, '4', '2x2', 1, 11, '1', 1, 11, '1', 1, 1, 1, 1, '.236.', 'espec', 'obs', '9911', 'jaison', '2007-12-10', 'jsn nhs', '2008-04-08'),
(5, 2, '3', '', 0, 1, '', 0, 1, '', 0, 0, 0, 0, '..', '', '', '', '', '0000-00-00', '', '2008-04-08');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `fluxo_itens`
-- 

CREATE TABLE `fluxo_itens` (
  `id` int(11) NOT NULL auto_increment,
  `id_item` int(11) default NULL,
  `id_fluxo` int(11) default NULL,
  `condicao` char(1) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2549 ;

-- 
-- Extraindo dados da tabela `fluxo_itens`
-- 

INSERT INTO `fluxo_itens` (`id`, `id_item`, `id_fluxo`, `condicao`) VALUES 
(2141, 1, 2, 'i'),
(2142, 2, 2, 'c'),
(2143, 3, 2, 'c'),
(2144, 4, 2, 'c'),
(2145, 5, 2, 'c'),
(2146, 6, 2, 'c'),
(2147, 7, 2, 'c'),
(2148, 8, 2, 'c'),
(2149, 9, 2, 'c'),
(2150, 10, 2, 'c'),
(2151, 11, 2, 'c'),
(2152, 12, 2, 'c'),
(2153, 13, 2, 'c'),
(2154, 14, 2, 'c'),
(2155, 15, 2, 'c'),
(2156, 16, 2, 'c'),
(2157, 17, 2, 'c'),
(2158, 18, 2, 'c'),
(2159, 19, 2, 'c'),
(2160, 20, 2, 'c'),
(2161, 21, 2, 'c'),
(2162, 22, 2, 'c'),
(2163, 23, 2, 'c'),
(2164, 24, 2, 'c'),
(2165, 25, 2, 'c'),
(2166, 26, 2, 'c'),
(2167, 27, 2, 'c'),
(2168, 28, 2, 'c'),
(2169, 29, 2, 'c'),
(2170, 30, 2, 'c'),
(2171, 31, 2, 'c'),
(2172, 32, 2, 'c'),
(2173, 33, 2, 'c'),
(2174, 34, 2, 'i'),
(2481, 1, 4, 'c'),
(2482, 2, 4, 'c'),
(2483, 3, 4, 'c'),
(2484, 4, 4, 'c'),
(2485, 5, 4, 'c'),
(2486, 6, 4, 'c'),
(2487, 7, 4, 'c'),
(2488, 8, 4, 'c'),
(2489, 9, 4, 'c'),
(2490, 10, 4, 'c'),
(2491, 11, 4, 'c'),
(2492, 12, 4, 'c'),
(2493, 13, 4, 'c'),
(2494, 14, 4, 'c'),
(2495, 15, 4, 'c'),
(2496, 16, 4, 'c'),
(2497, 17, 4, 'c'),
(2498, 18, 4, 'c'),
(2499, 19, 4, 'c'),
(2500, 20, 4, 'c'),
(2501, 21, 4, 'c'),
(2502, 22, 4, 'c'),
(2503, 23, 4, 'c'),
(2504, 24, 4, 'c'),
(2505, 25, 4, 'c'),
(2506, 26, 4, 'c'),
(2507, 27, 4, 'c'),
(2508, 28, 4, 'c'),
(2509, 29, 4, 'c'),
(2510, 30, 4, 'c'),
(2511, 31, 4, 'c'),
(2512, 32, 4, 'c'),
(2513, 33, 4, 'c'),
(2514, 34, 4, 'c'),
(2515, 1, 5, ''),
(2516, 2, 5, ''),
(2517, 3, 5, ''),
(2518, 4, 5, ''),
(2519, 5, 5, ''),
(2520, 6, 5, ''),
(2521, 7, 5, ''),
(2522, 8, 5, ''),
(2523, 9, 5, ''),
(2524, 10, 5, ''),
(2525, 11, 5, ''),
(2526, 12, 5, ''),
(2527, 13, 5, ''),
(2528, 14, 5, ''),
(2529, 15, 5, ''),
(2530, 16, 5, ''),
(2531, 17, 5, ''),
(2532, 18, 5, ''),
(2533, 19, 5, ''),
(2534, 20, 5, ''),
(2535, 21, 5, ''),
(2536, 22, 5, ''),
(2537, 23, 5, ''),
(2538, 24, 5, ''),
(2539, 25, 5, ''),
(2540, 26, 5, ''),
(2541, 27, 5, ''),
(2542, 28, 5, ''),
(2543, 29, 5, ''),
(2544, 30, 5, ''),
(2545, 31, 5, ''),
(2546, 32, 5, ''),
(2547, 33, 5, ''),
(2548, 34, 5, '');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `fluxo_parametros`
-- 

CREATE TABLE `fluxo_parametros` (
  `id` int(11) NOT NULL auto_increment,
  `id_fluxo` int(11) default NULL,
  `id_parametro` int(11) default NULL,
  `valor` varchar(255) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=321 ;

-- 
-- Extraindo dados da tabela `fluxo_parametros`
-- 

INSERT INTO `fluxo_parametros` (`id`, `id_fluxo`, `id_parametro`, `valor`) VALUES 
(261, 2, 1, '123'),
(262, 2, 2, '123'),
(263, 2, 3, '321'),
(264, 2, 4, '444'),
(265, 2, 5, '232'),
(311, 4, 1, '1'),
(312, 4, 2, '2'),
(313, 4, 3, '3'),
(314, 4, 4, '4'),
(315, 4, 5, '5'),
(316, 5, 1, ''),
(317, 5, 2, ''),
(318, 5, 3, ''),
(319, 5, 4, ''),
(320, 5, 5, '');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `fluxo_teste_cont`
-- 

CREATE TABLE `fluxo_teste_cont` (
  `id` int(11) NOT NULL auto_increment,
  `id_fluxo` int(11) default NULL,
  `id_filtro_cont` int(11) default NULL,
  `p1` varchar(255) collate latin1_general_ci default NULL,
  `p2` varchar(255) collate latin1_general_ci default NULL,
  `p3` varchar(255) collate latin1_general_ci default NULL,
  `p4` varchar(255) collate latin1_general_ci default NULL,
  `p5` varchar(255) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=79 ;

-- 
-- Extraindo dados da tabela `fluxo_teste_cont`
-- 

INSERT INTO `fluxo_teste_cont` (`id`, `id_fluxo`, `id_filtro_cont`, `p1`, `p2`, `p3`, `p4`, `p5`) VALUES 
(43, 2, 1, '1@!@2', '3@!@4', '5@!@6', '7@!@8', '9@!@00'),
(44, 2, 2, 'q@!@w', 'e@!@r', 't@!@y', 'u@!@i', 'o@!@p'),
(45, 2, 3, 'a@!@s', 'd@!@f', 'g@!@h', 'j@!@k', 'l@!@;'),
(73, 4, 1, '1@!@2', '3@!@4', '5@!@6', '7@!@8', '9@!@0'),
(74, 4, 2, '11@!@12', '13@!@14', '15@!@16', '17@!@18', '19@!@20'),
(75, 4, 3, '21@!@22', '23@!@24', '25@!@26', '27@!@28', '29@!@30'),
(76, 5, 1, '@!@', '@!@', '@!@', '@!@', '@!@'),
(77, 5, 2, '@!@', '@!@', '@!@', '@!@', '@!@'),
(78, 5, 3, '@!@', '@!@', '@!@', '@!@', '@!@');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `fluxo_teste_fuga`
-- 

CREATE TABLE `fluxo_teste_fuga` (
  `id` int(11) NOT NULL auto_increment,
  `id_fluxo` int(11) default NULL,
  `id_filtro_fuga` int(11) default NULL,
  `valor` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=349 ;

-- 
-- Extraindo dados da tabela `fluxo_teste_fuga`
-- 

INSERT INTO `fluxo_teste_fuga` (`id`, `id_fluxo`, `id_filtro_fuga`, `valor`) VALUES 
(277, 2, 1, 1),
(278, 2, 2, 1),
(279, 2, 3, 1),
(280, 2, 4, 1),
(281, 2, 5, 1),
(282, 2, 6, 0),
(337, 4, 1, 0),
(338, 4, 2, 1),
(339, 4, 3, 0),
(340, 4, 4, 1),
(341, 4, 5, 0),
(342, 4, 6, 1),
(343, 5, 1, 0),
(344, 5, 2, 0),
(345, 5, 3, 0),
(346, 5, 4, 0),
(347, 5, 5, 0),
(348, 5, 6, 1);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `fluxo_teste_fuga_vaz`
-- 

CREATE TABLE `fluxo_teste_fuga_vaz` (
  `id` int(11) NOT NULL auto_increment,
  `id_fluxo` int(11) default NULL,
  `id_vaz` int(11) default NULL,
  `valor_vaz` int(11) default NULL,
  `causa_vaz` text collate latin1_general_ci,
  `reparado_vaz` text collate latin1_general_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=771816 ;

-- 
-- Extraindo dados da tabela `fluxo_teste_fuga_vaz`
-- 

INSERT INTO `fluxo_teste_fuga_vaz` (`id`, `id_fluxo`, `id_vaz`, `valor_vaz`, `causa_vaz`, `reparado_vaz`) VALUES 
(771810, 4, 1, 1, '', ''),
(771811, 4, 2, 0, '', ''),
(771812, 4, 3, 1, 'hoho', 'huhu'),
(771813, 5, 1, 0, '', ''),
(771814, 5, 2, 0, '', ''),
(771815, 5, 3, 0, '', '');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `fluxo_teste_vel`
-- 

CREATE TABLE `fluxo_teste_vel` (
  `id` int(11) NOT NULL auto_increment,
  `id_fluxo` int(11) default NULL,
  `id_teste_vel` int(11) default NULL,
  `f1` varchar(255) collate latin1_general_ci default NULL,
  `f2` varchar(255) collate latin1_general_ci default NULL,
  `f3` varchar(255) collate latin1_general_ci default NULL,
  `f4` varchar(255) collate latin1_general_ci default NULL,
  `f5` varchar(255) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=79 ;

-- 
-- Extraindo dados da tabela `fluxo_teste_vel`
-- 

INSERT INTO `fluxo_teste_vel` (`id`, `id_fluxo`, `id_teste_vel`, `f1`, `f2`, `f3`, `f4`, `f5`) VALUES 
(55, 2, 1, 'a@!@a', 'b@!@b', 'c@!@c', 'd@!@d', 'e@!@e'),
(56, 2, 2, '11', '22', '33', '44', '55'),
(75, 4, 1, '1@!@2', '3@!@4', '5@!@6', '7@!@8', '9@!@0'),
(76, 4, 2, '11', '12', '13', '14', '15'),
(77, 5, 1, '@!@', '@!@', '@!@', '@!@', '@!@'),
(78, 5, 2, '', '', '', '', '');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `os_agua`
-- 

CREATE TABLE `os_agua` (
  `id` int(11) NOT NULL auto_increment,
  `id_os` int(11) default NULL,
  `servico_executado` text collate latin1_general_ci,
  `parametro1` text collate latin1_general_ci,
  `parametro2` text collate latin1_general_ci,
  `parametro3` text collate latin1_general_ci,
  `parametro4` text collate latin1_general_ci,
  `parametro5` text collate latin1_general_ci,
  `parametro6` text collate latin1_general_ci,
  `parametro7` text collate latin1_general_ci,
  `parametro8` text collate latin1_general_ci,
  `parametro9` text collate latin1_general_ci,
  `ver_50micras` tinyint(3) default NULL,
  `ver_20micras` tinyint(3) default NULL,
  `ver_01micra` tinyint(3) default NULL,
  `obs_50micras` text collate latin1_general_ci,
  `obs_20micras` text collate latin1_general_ci,
  `obs_01micra` text collate latin1_general_ci,
  `ntroca` tinyint(3) default NULL,
  `ver_formol40` tinyint(3) default NULL,
  `ver_hipoclorito12` tinyint(3) default NULL,
  `ver_salgrosso` tinyint(3) default NULL,
  `ver_desibac` tinyint(3) default NULL,
  `obs_formol40` text collate latin1_general_ci,
  `obs_hipoclorito12` text collate latin1_general_ci,
  `obs_salgrosso` text collate latin1_general_ci,
  `obs_desibac` text collate latin1_general_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

-- 
-- Extraindo dados da tabela `os_agua`
-- 

INSERT INTO `os_agua` (`id`, `id_os`, `servico_executado`, `parametro1`, `parametro2`, `parametro3`, `parametro4`, `parametro5`, `parametro6`, `parametro7`, `parametro8`, `parametro9`, `ver_50micras`, `ver_20micras`, `ver_01micra`, `obs_50micras`, `obs_20micras`, `obs_01micra`, `ntroca`, `ver_formol40`, `ver_hipoclorito12`, `ver_salgrosso`, `ver_desibac`, `obs_formol40`, `obs_hipoclorito12`, `obs_salgrosso`, `obs_desibac`) VALUES 
(4, 12, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, '', 'asdasdasd', '', 0, 0, 0, 1, 1, '', '', '213123123', '123123123123');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `os_agua_analise`
-- 

CREATE TABLE `os_agua_analise` (
  `id` int(11) NOT NULL auto_increment,
  `id_os` int(11) default NULL,
  `id_carac` int(11) default NULL,
  `parametro` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=225 ;

-- 
-- Extraindo dados da tabela `os_agua_analise`
-- 

INSERT INTO `os_agua_analise` (`id`, `id_os`, `id_carac`, `parametro`) VALUES 
(216, 12, 1, 1),
(217, 12, 2, 1),
(218, 12, 3, 1),
(219, 12, 4, 1),
(220, 12, 5, 1),
(221, 12, 6, 1),
(222, 12, 7, 1),
(223, 12, 8, 1),
(224, 12, 9, 1);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `os_hemodialise`
-- 

CREATE TABLE `os_hemodialise` (
  `id` int(11) NOT NULL auto_increment,
  `id_os` int(11) default NULL,
  `servico_executado` text collate latin1_general_ci,
  `material_utilizado` text collate latin1_general_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

-- 
-- Extraindo dados da tabela `os_hemodialise`
-- 

INSERT INTO `os_hemodialise` (`id`, `id_os`, `servico_executado`, `material_utilizado`) VALUES 
(3, 11, 'asdasdasdasd', 'asdasdasdasdasdasd');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `os_laminar`
-- 

CREATE TABLE `os_laminar` (
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Extraindo dados da tabela `os_laminar`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `oss`
-- 

CREATE TABLE `oss` (
  `id_os` int(11) NOT NULL auto_increment,
  `status_os` tinyint(3) default NULL,
  `id_empresa` int(11) default NULL,
  `data_os` timestamp NULL default NULL,
  `solicitante` varchar(255) collate latin1_general_ci default NULL,
  `tel_solicitante` varchar(31) collate latin1_general_ci default NULL,
  `prioridade` tinyint(3) default NULL,
  `id_tecnico` int(11) default NULL,
  `tipo_atendimento` char(1) collate latin1_general_ci default NULL,
  `id_servico` int(11) default NULL,
  `equipamento` varchar(255) collate latin1_general_ci default NULL,
  `nserie` varchar(255) collate latin1_general_ci default NULL,
  `obs` text collate latin1_general_ci,
  `obs_gerais` text collate latin1_general_ci,
  `obs_gerais_tecnico` text collate latin1_general_ci,
  PRIMARY KEY  (`id_os`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=13 ;

-- 
-- Extraindo dados da tabela `oss`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `servicos`
-- 

CREATE TABLE `servicos` (
  `id_servico` int(11) NOT NULL auto_increment,
  `servico` varchar(255) collate latin1_general_ci default NULL,
  `descricao` text collate latin1_general_ci,
  PRIMARY KEY  (`id_servico`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

-- 
-- Extraindo dados da tabela `servicos`
-- 

INSERT INTO `servicos` (`id_servico`, `servico`, `descricao`) VALUES 
(1, 'Equipamento de Hemodiálise', NULL),
(2, 'Tratamento de Água', NULL),
(3, 'Equipamento de Fluxo Laminar', NULL);

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `tecnicos`
-- 

CREATE TABLE `tecnicos` (
  `id_tecnico` int(11) NOT NULL auto_increment,
  `tecnico` varchar(255) collate latin1_general_ci default '',
  PRIMARY KEY  (`id_tecnico`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

-- 
-- Extraindo dados da tabela `tecnicos`
-- 

INSERT INTO `tecnicos` (`id_tecnico`, `tecnico`) VALUES 
(1, 'Francisco'),
(2, 'Carlos'),
(3, 'Fabiano');
